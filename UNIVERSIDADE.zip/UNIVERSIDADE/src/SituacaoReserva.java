enum SituacaoReserva {                                                  // Powered by: BRUNO CASÉ and ZAIRA DUTRA
                                                                          //Last att: 12:58 pm  (21/11/2023)
    APROVADA,
    REPROVADA
}